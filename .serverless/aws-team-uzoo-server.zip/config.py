class Config :
    JWT_SECRET_KEY = 'yhacademy1029##heelo'
    JWT_ACCESS_TOKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True

    ACCESS_KEY = 'AKIAVO5I77VULVBKKGHT'
    SECRET_ACCESS = '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'

    #   # AWS block2                                                
    # ACCESS_KEY = 'AKIAVO5I77VUGAZ2Y6V7'                         
    # SECRET_ACCESS = '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'  
                                                                
                                                                
                                                                
    # # S3 버킷이름과, 기본 URL 주소 셋팅                         
    # S3_BUCKET = 'jaehoon-image-test'                             
    # S3_LOCATION = 'https://jaehoon-image-test.s3.amazonaws.com/'