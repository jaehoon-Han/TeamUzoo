import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='hanjaehoon',
    application_name='aws-team-uzoo-server',
    app_uid='DLqMlpvMT4qbq13XRg',
    org_uid='ac70aef0-cf81-4578-8c0e-248d4c8db7cb',
    deployment_uid='cf0d0888-f0c1-4f2b-9d72-3f59809d544d',
    service_name='aws-team-uzoo-server',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-team-uzoo-server-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
